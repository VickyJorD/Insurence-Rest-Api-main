Insurance Management System


This is a simple Insurance Management System that allows you to manage clients, insurance policies, and claims.

Technologies Used
Java 11

Spring Boot 2.5.4

Spring Data JPA

H2 in-memory database

Maven


Project Structure
The project follows a standard Spring Boot project structure, with the following packages:

com.example.insurance: Main package.
com.example.insurance.controller: API endpoints.
com.example.insurance.model: Domain models.
com.example.insurance.repository: Spring Data JPA repositories.
com.example.insurance.service: Business logic.
API Endpoints


The API provides the following endpoints:

Clients
GET /api/clients: Fetch all clients.
GET /api/clients/{id}: Fetch a specific client by ID.
POST /api/clients: Create a new client.
PUT /api/clients/{id}: Update a client's information.
DELETE /api/clients/{id}: Delete a client.


Insurance Policies
GET /api/policies: Fetch all insurance policies.
GET /api/policies/{id}: Fetch a specific insurance policy by ID.
POST /api/policies: Create a new insurance policy.
PUT /api/policies/{id}: Update an insurance policy.
DELETE /api/policies/{id}: Delete an insurance policy.


Claims
GET /api/claims: Fetch all claims.
GET /api/claims/{id}: Fetch a specific claim by ID.
POST /api/claims: Create a new claim.
PUT /api/claims/{id}: Update a claim's information.
DELETE /api/claims/{id}: Delete a claim.


Running the Application
To run the application locally, follow these steps:



Clone the repository: git clone https://github.com/your-username/insurance-management-system.git
Navigate to the project directory: cd insurance-management-system
Build the project: mvn clean install


Run the application: java -jar target/insurance-management-system-0.0.1-SNAPSHOT.jar

The application should now be running at http://localhost:8080.

Conclusion
This Insurance Management System provides a simple way to manage clients, insurance policies, 
and claims. It is built using Spring Boot and Spring Data JPA, and uses an H2 in-memory database for 
testing purposes. The API provides CRUD endpoints for each of the domain models, and input validation 
is enforced to ensure proper API usage and data integrity.