package com.insurence.insurenceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsurenceapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
